# Модуль 11. Взаємодія з файловою системою

## Зміст

1. [Модель потоків у C#. Простір System.IO](#модель-потоків-у-c-простір-systemio)
2. [Клас Stream](#клас-stream)
3. [Аналіз байтових класів потоків](#аналіз-байтових-класів-потоків)
4. [Аналіз символьних класів потоків](#аналіз-символьних-класів-потоків)
5. [Аналіз двійкових класів потоків](#аналіз-двійкових-класів-потоків)
6. [FileStream](#filestream)
7. [StreamWriter](#streamwriter)
8. [StreamReader](#streamreader)
9. [BinaryWriter](#binarywriter)
10. [BinaryReader](#binaryreader)
11. [Directory, DirectoryInfo, FileInfo](#directory-directoryinfo-fileinfo)
12. [Регулярні вирази](#регулярні-вирази)

---
# Tема даного репозитарію "Взаємодія з файловою системою
## 1. Модель потоків у C#"
Практично всі операції, пов'язані з **введенням/виведенням** будь-якої послідовності байтів (запис/читання файлів, використання пристроїв введення-виведення, потоку шифрування та ін.) у .NET Framework здійснюються за допомогою потоків.

Потік - це **абстракція**, яка використовується як для читання, так і для запису інформації. Хоча потоки пов'язані з різними фізичними пристроями, їхня поведінка багато в чому аналогічна і не залежить від конкретного пристрою, тому класи введення-виведення можуть використовуватися з пристроями різних типів.

Основним простором імен у .NET Framework, пов'язаним із введенням-виведенням інформації, є `System.IO`, який містить необхідний набір класів, структур, делегатів і перелічень, більшість із яких буде розглянуто в цьому уроці.

## Простір System.IO

**System.IO** - це простір імен, який містить класи для роботи з файлами, директоріями та потоками даних.

Основні класи:
- `Stream` - базовий клас для всіх потоків
- `FileStream` - робота з файлами
- `MemoryStream` - робота з пам'яттю
- `StreamReader` / `StreamWriter` - робота з текстом
- `BinaryReader` / `BinaryWriter` - робота з двійковими даними

### Переваги потокової моделі:

1. **Уніфікований підхід** - однаковий спосіб роботи з різними джерелами даних
2. **Ефективність** - дані обробляються частинами, а не повністю в пам'яті
3. **Гнучкість** - можна легко змінювати джерела даних
---
## 2. Що таке потік? Клас Stream.
**Абстрагуємося від реальності** 
Щоб зрозуміти - найкраще уявити водопровідну трубу.

Програмісту байдуже, звідки береться вода (з озера чи з водосховища). 

`Головне` - у нього є труба, з якої можна або пити (читати дані), або наливати туди воду (записувати дані).

---
**Потік (Stream)** - це абстракція послідовного доступу до даних. Потік представляє послідовність байтів, які можна читати або записувати. Це спосіб передачі даних між вашою програмою та зовнішнім світом (файлами, мережею, пам'яттю).

Клас `Stream` каже: "Мені байдуже, куди ти пишеш - у файл на диску чи повідомлення в Telegram. Я дам тобі однаковий набір інструментів для цього".

Клас `Stream` із простору імен `System.IO` є базовим класом для всіх потоків. Він забезпечує універсальне представлення різних типів введення та виведення, ізолюючи програміста від окремих відомостей операційної системи та базових пристроїв. Однак залежно від базового джерела або сховища даних потоки можуть підтримувати тільки деякі можливості, що надаються класом Stream.

| Властивість | Питання до потоку | Що це означає? |
| :--- | :--- | :--- |
| **`CanRead`** | 📖 Можна читати? | Чи можемо ми дістати дані з цієї "труби". |
| **`CanWrite`** | ✍️ Можна записувати? | Чи можемо ми відправити (записати) дані в цю "трубу". |
| **`CanSeek`** | ⏪ Можна "перемотати"? | Чи можна перестрибнути в середину або в кінець даних (як на касеті чи флешці). |

Якщо потік підтримує `Seeking (CanSeek == true)`, ми можемо керувати "курсором" усередині даних:
- Position: Показує, де ми зараз знаходимося (на якому байті).
- Seek(): Дозволяє "стрибнути" на певну відстань від початку, кінця або поточної позиції.
- Length: Показує загальний розмір (розмір файлу).
---

### 🕹️ Керування позицією та буфером

| Метод / Властивість | Опис дії | Навіщо це потрібно? |
| :--- | :--- | :--- |
| **`Position`** | Поточний байт | Показує, де зараз знаходиться "курсор" читання/запису. |
| **`Length`** | Загальний розмір | Показує загальну кількість байтів у потоці. |
| **`Seek()`** | Змінити позицію | Дозволяє стрибнути на певну відстань від початку або кінця. |
| **`Flush()`** | Очистити буфер | Примусово записує дані з пам'яті (буфера) безпосередньо в джерело. |
| **`Close()`** | Закрити потік | Звільняє ресурси (файли, мережу) для інших програм. |

### Основні методи:

- `Read(byte[] buffer, int offset, int count)` - читає дані з потоку
- `Write(byte[] buffer, int offset, int count)` - записує дані в потік
- `Seek(long offset, SeekOrigin origin)` - змінює позицію в потоці
- `Flush()` - очищає буфери
- `Close()` / `Dispose()` - закриває потік

### Приклад:

```csharp
// Базовий приклад роботи з Stream
using (Stream stream = new MemoryStream())
{
    byte[] data = { 1, 2, 3, 4, 5 };
    stream.Write(data, 0, data.Length);
    
    stream.Position = 0; // Повертаємось на початок
    
    byte[] buffer = new byte[5];
    int bytesRead = stream.Read(buffer, 0, 5);
}
```
---

## 3. Аналіз байтових класів потоків

### FileStream

**FileStream** - клас для роботи з файлами на диску на рівні байтів.

**Особливості:**
- Працює з байтами
- Підтримує асинхронні операції
- Може працювати з великими файлами
- Підтримує різні режими доступу (Read, Write, ReadWrite)

**Режими відкриття:**
- `FileMode.Create` - створює новий файл (перезаписує існуючий)
- `FileMode.Open` - відкриває існуючий файл
- `FileMode.Append` - відкриває для додавання в кінець
- `FileMode.CreateNew` - створює новий файл (помилка якщо існує)

**Приклад:**

```csharp
// Запис байтів у файл
using (FileStream fs = new FileStream("data.bin", FileMode.Create))
{
    byte[] data = { 65, 66, 67, 68, 69 }; // ABCDE
    fs.Write(data, 0, data.Length);
}

// Читання байтів з файлу
using (FileStream fs = new FileStream("data.bin", FileMode.Open))
{
    byte[] buffer = new byte[5];
    int bytesRead = fs.Read(buffer, 0, 5);
    // buffer містить: 65, 66, 67, 68, 69
}
```

### MemoryStream

**MemoryStream** - клас для роботи з даними в оперативній пам'яті.

**Особливості:**
- Дані зберігаються в оперативній пам'яті
- Швидкий доступ
- Не потребує файлової системи

**Коли це треба?** Наприклад, ви завантажили картинку з інтернету, хочете її обробити в пам'яті, а вже потім зберегти на диск. Дані зникнуть, як тільки програма вимкнеться або потік буде закритий.

**Приклад:**

```csharp
using (MemoryStream ms = new MemoryStream())
{
    byte[] data = { 1, 2, 3, 4, 5 };
    ms.Write(data, 0, data.Length);
    
    ms.Position = 0;
    byte[] result = ms.ToArray(); // Отримуємо всі дані
}
```
### BufferedStream
Він не має власного сховища, він працює "поверх" іншого потоку("тюнінг").

**Принцип:** Замість того, щоб писати по 1 байту на диск 1000 разів (це повільно), він чекає, поки назбирається 1000 байтів у пам'яті, і записує їх одним махом. 

Це як збирати сміття в пакет, а не виносити кожну папірці до контейнера окремо.

### 📦 Класи-оболонки (Wrappers)
Оскільки працювати з масивами байтів (byte[]) вручну важко, .NET пропонує "перекладачі":

**BinaryReader / BinaryWriter**: Перетворюють байти у типи даних C# (int, double, bool).

**StreamReader / StreamWriter**: Перетворюють байти у символи та рядки (char, string).
```csharp
using System.Net.Sockets;
using System.IO;

// Уявімо, що у нас є підключення до сервера
TcpClient client = new TcpClient("127.0.0.1", 8080);
NetworkStream ns = client.GetStream();

// ОБОВ'ЯЗКОВО використовуємо BufferedStream поверх мережевого потоку
using (BufferedStream bs = new BufferedStream(ns))
{
    for (int i = 0; i < 1000; i++)
    {
        byte[] tinyData = new byte[] { 1 }; // Дуже маленька порція даних
        bs.Write(tinyData, 0, tinyData.Length);
    }
    bs.Flush(); // Відправляємо всі 1000 байт одним махом (одним пакетом)
}
```
---

## 4. Аналіз символьних класів потоків

**StreamReader** - клас для читання тексту з потоку.

**Особливості:**
- Автоматично обробляє кодування (UTF-8 за замовчуванням)
- Працює з символами та рядками
- Підтримує різні методи читання

**Основні методи:**
- `ReadLine()` - читає один рядок
- `ReadToEnd()` - читає весь файл
- `Read()` - читає один символ
- `ReadBlock()` - читає блок символів

**Приклад:**

```csharp
using (StreamReader reader = new StreamReader("text.txt"))
{
    string line;
    while ((line = reader.ReadLine()) != null)
    {
        Console.WriteLine(line);
    }
}

// Або прочитати весь файл одразу
using (StreamReader reader = new StreamReader("text.txt"))
{
    string content = reader.ReadToEnd();
    Console.WriteLine(content);
}
```

### StreamWriter

**StreamWriter** - клас для запису тексту в потік.

**Особливості:**
- Автоматично обробляє кодування
- Працює з символами та рядками
- Підтримує буферизацію

**Основні методи:**
- `WriteLine()` - записує рядок з переносом
- `Write()` - записує без переносу
- `Flush()` - очищає буфер

**Приклад:**

```csharp
using (StreamWriter writer = new StreamWriter("output.txt"))
{
    writer.WriteLine("Перший рядок");
    writer.WriteLine("Другий рядок");
    writer.Write("Третій рядок без переносу");
}

// Додавання в кінець файлу
using (StreamWriter writer = new StreamWriter("output.txt", append: true))
{
    writer.WriteLine("Новий рядок");
}
```

---

## 5. Аналіз двійкових класів потоків

**BinaryReader** - клас для читання двійкових даних з потоку.

Класи BinaryReader та BinaryWriter - це класи-оболонки. Вони не є самостійними потоками, а "одягаються" поверх існуючого байтового потоку (наприклад, FileStream), щоб автоматично конвертувати байти у стандартні типи даних C#.
**Особливості:**
- Читає примітивні типи даних (int, double, string тощо)
- Зберігає дані в компактному форматі
- Ефективний для структурованих даних

**Основні методи:**
- `ReadInt32()` - читає int
- `ReadDouble()` - читає double
- `ReadString()` - читає string
- `ReadBytes()` - читає масив байтів
- `ReadBoolean()` - читає bool

**Приклад:**

```csharp
using (BinaryReader reader = new BinaryReader(File.OpenRead("data.bin")))
{
    int number = reader.ReadInt32();
    double value = reader.ReadDouble();
    string text = reader.ReadString();
    bool flag = reader.ReadBoolean();
}
```

### BinaryWriter

**BinaryWriter** - клас для запису двійкових даних у потік.

**Особливості:**
- Записує примітивні типи даних
- Компактне зберігання
- Ефективний для структурованих даних

**Основні методи:**
- `Write(int)` - записує int
- `Write(double)` - записує double
- `Write(string)` - записує string
- `Write(bool)` - записує bool

**Приклад:**

```csharp
using (BinaryWriter writer = new BinaryWriter(File.Create("data.bin")))
{
    writer.Write(42);
    writer.Write(3.14);
    writer.Write("Hello");
    writer.Write(true);
}
```

---

## 6. FileStream
Клас **FileStream** - це основний інструмент для побайтового читання та запису файлів. При створенні об'єкта ми маємо чітко вказати ОС, що ми збираємося робити з файлом.
```csharp
FileStream fs = new FileStream(path, FileMode, FileAccess, FileShare);
```
### 1️⃣ FileMode (Як відкрити файл?)
Визначає логіку взаємодії з файлом на рівні його створення або відкриття.

| Значення | Опис дії | Якщо файлу НЕМАЄ |
| :--- | :--- | :--- |
| **`Create`** | Створює новий файл. Якщо вже існує — **перезаписує** його. | Створює новий. |
| **`CreateNew`** | Створює новий файл. | Помилка (`IOException`). |
| **`Open`** | Відкриває існуючий файл. | Помилка (`FileNotFoundException`). |
| **`OpenOrCreate`** | Відкриває існуючий або створює новий, якщо не знайдено. | Створює новий. |
| **`Append`** | Відкриває файл і ставить курсор у кінець для дозапису. | Створює новий. |
| **`Truncate`** | Відкриває існуючий файл і **видаляє весь вміст** (розмір 0). | Помилка (`IOException`). |

---
### 2️⃣ FileAccess (Що ми будемо робити?)
Визначає права вашої програми на операції всередині цього потоку.

| Значення | Опис можливостей |
| :--- | :--- |
| **`Read`** | Тільки для читання. Спроба запису викличе помилку. |
| **`Write`** | Тільки для запису. Спроба читання викличе помилку. |
| **`ReadWrite`** | Повний доступ: дозволяє і читати дані, і записувати їх. |

---

### 3️⃣ FileShare (Чи пускати інші програми?)
Визначає, чи зможуть інші процеси відкрити цей файл, поки він відкритий у вас.

| Значення | Доступ для інших програм |
| :--- | :--- |
| **`None`** | **Заборонено все.** Жоден процес не відкриє файл, поки ви його не закриєте. |
| **`Read`** | Інші програми можуть тільки **читати** файл паралельно з вами. |
| **`Write`** | Інші програми можуть тільки **записувати** у файл паралельно з вами. |
| **`ReadWrite`** | Інші програми можуть і читати, і записувати у файл. |
| **`Delete`** | Дозволяє іншим програмам видалити файл, навіть якщо він відкритий. |

---

💡 Порада щодо шляхів до файлів
У C# зручно використовувати символ @ перед рядком, щоб не дублювати слеші:
- string path = "C:\\Data\\file.txt"; — звичайно.
- string path = @"C:\Data\file.txt"; — рекомендовано.
### Детальний приклад використання FileStream

**Створення та запис:**

```csharp
string fileName = "example.bin";

// Створення нового файлу
using (FileStream fs = new FileStream(fileName, FileMode.Create))
{
    byte[] data = Encoding.UTF8.GetBytes("Hello, FileStream!");
    fs.Write(data, 0, data.Length);
    fs.Flush(); // Забезпечує запис на диск
}
```

**Читання з позиціонуванням:**

```csharp
using (FileStream fs = new FileStream(fileName, FileMode.Open))
{
    // Переміщення на позицію 7
    fs.Seek(7, SeekOrigin.Begin);
    
    byte[] buffer = new byte[5];
    int bytesRead = fs.Read(buffer, 0, 5);
    
    string result = Encoding.UTF8.GetString(buffer, 0, bytesRead);
    Console.WriteLine(result); // "FileS"
}
```

**Асинхронна робота:**

```csharp
async Task WriteFileAsync(string fileName, byte[] data)
{
    using (FileStream fs = new FileStream(fileName, FileMode.Create))
    {
        await fs.WriteAsync(data, 0, data.Length);
        await fs.FlushAsync();
    }
}
```
---

## Directory, DirectoryInfo, FileInfo

### Статичні класи File та Directory

**File** - статичний клас для роботи з файлами.

**Основні методи:**
- `File.Exists(path)` - перевірка існування файлу
- `File.ReadAllText(path)` - читання всього тексту
- `File.WriteAllText(path, content)` - запис тексту
- `File.Delete(path)` - видалення файлу
- `File.Copy(source, dest)` - копіювання файлу
- `File.Move(source, dest)` - переміщення файлу

**Directory** - статичний клас для роботи з директоріями.

**Основні методи:**
- `Directory.Exists(path)` - перевірка існування директорії
- `Directory.CreateDirectory(path)` - створення директорії
- `Directory.Delete(path)` - видалення директорії
- `Directory.GetFiles(path)` - отримання списку файлів
- `Directory.GetDirectories(path)` - отримання списку піддиректорій

**Приклади:**

```csharp
// Робота з файлами
string filePath = "test.txt";

if (!File.Exists(filePath))
{
    File.WriteAllText(filePath, "Привіт, світ!");
}

string content = File.ReadAllText(filePath);
Console.WriteLine(content);

// Робота з директоріями
string dirPath = "MyFolder";

if (!Directory.Exists(dirPath))
{
    Directory.CreateDirectory(dirPath);
}

string[] files = Directory.GetFiles(dirPath);
foreach (string file in files)
{
    Console.WriteLine(file);
}
```

### Класи FileInfo та DirectoryInfo

**FileInfo** - клас для отримання інформації про файл.

**Основні властивості:**
- `Name` - ім'я файлу
- `FullName` - повний шлях
- `Length` - розмір файлу в байтах
- `CreationTime` - час створення
- `LastWriteTime` - час останньої зміни
- `Extension` - розширення файлу

**DirectoryInfo** - клас для отримання інформації про директорію.

**Основні властивості:**
- `Name` - ім'я директорії
- `FullName` - повний шлях
- `CreationTime` - час створення
- `GetFiles()` - отримання файлів
- `GetDirectories()` - отримання піддиректорій

**Приклади:**

```csharp
// Робота з FileInfo
FileInfo fileInfo = new FileInfo("example.txt");

if (fileInfo.Exists)
{
    Console.WriteLine($"Ім'я: {fileInfo.Name}");
    Console.WriteLine($"Розмір: {fileInfo.Length} байт");
    Console.WriteLine($"Створено: {fileInfo.CreationTime}");
    Console.WriteLine($"Змінено: {fileInfo.LastWriteTime}");
    Console.WriteLine($"Розширення: {fileInfo.Extension}");
}

// Робота з DirectoryInfo
DirectoryInfo dirInfo = new DirectoryInfo(".");

Console.WriteLine($"Поточна директорія: {dirInfo.FullName}");

FileInfo[] files = dirInfo.GetFiles("*.txt");
foreach (FileInfo file in files)
{
    Console.WriteLine($"Файл: {file.Name}, Розмір: {file.Length}");
}

DirectoryInfo[] dirs = dirInfo.GetDirectories();
foreach (DirectoryInfo dir in dirs)
{
    Console.WriteLine($"Директорія: {dir.Name}");
}
```

---

## Регулярні вирази

### Простір System.Text.RegularExpressions

**Regex** - клас для роботи з регулярними виразами.

### Основні поняття:

**Регулярний вираз** - це патерн для пошуку та заміни тексту.

### Основні метасимволи:

- `.` - будь-який символ
- `\d` - цифра (0-9)
- `\w` - буква, цифра або підкреслення
- `\s` - пробіл
- `^` - початок рядка
- `$` - кінець рядка
- `*` - 0 або більше повторень
- `+` - 1 або більше повторень
- `?` - 0 або 1 повторення
- `{n}` - точно n повторень
- `{n,m}` - від n до m повторень
- `[]` - набір символів
- `|` - або (альтернатива)
- `()` - група

Під час написання спеціальних символів регулярного виразу є необхідність використовувати символ «зворотна коса риска» (\), який є символом екранування. Тому для коректного запису рядка необхідно або екранувати сам символ, або ставити символ '@' перед усім рядком, створюючи дослівний рядок. Зазвичай використовується другий підхід.

### Основні методи Regex:

- `IsMatch(input, pattern)` - перевірка відповідності
- `Match(input, pattern)` - знаходження першого збігу
- `Matches(input, pattern)` - знаходження всіх збігів
- `Replace(input, pattern, replacement)` - заміна
- `Split(input, pattern)` - розділення рядка

### Приклади:

**Перевірка формату:**

```csharp
// Перевірка email
string email = "user@example.com";
string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

if (Regex.IsMatch(email, pattern))
{
    Console.WriteLine("Email валідний");
}
```

**Пошук чисел:**

```csharp
string text = "Ціна товару: 1234 грн, знижка: 15%";
string pattern = @"\d+";

MatchCollection matches = Regex.Matches(text, pattern);
foreach (Match match in matches)
{
    Console.WriteLine($"Знайдено число: {match.Value}");
}
```

**Заміна:**

```csharp
string text = "Телефон: 050-123-45-67";
string pattern = @"\d{3}-\d{3}-\d{2}-\d{2}";
string replacement = "XXX-XXX-XX-XX";

string result = Regex.Replace(text, pattern, replacement);
Console.WriteLine(result); // "Телефон: XXX-XXX-XX-XX"
```

**Розділення:**

```csharp
string text = "apple,banana,orange,grape";
string pattern = @",";

string[] fruits = Regex.Split(text, pattern);
foreach (string fruit in fruits)
{
    Console.WriteLine(fruit);
}
```

**Групи:**

```csharp
string text = "Дата: 2024-12-15";
string pattern = @"(\d{4})-(\d{2})-(\d{2})";

Match match = Regex.Match(text, pattern);
if (match.Success)
{
    Console.WriteLine($"Рік: {match.Groups[1].Value}");
    Console.WriteLine($"Місяць: {match.Groups[2].Value}");
    Console.WriteLine($"День: {match.Groups[3].Value}");
}
```

**Валідація телефону:**

```csharp
string phone = "+380501234567";
string pattern = @"^\+380\d{9}$";

if (Regex.IsMatch(phone, pattern))
{
    Console.WriteLine("Телефон валідний");
}
```

**Пошук слів:**

```csharp
string text = "C# це мова програмування. C# дуже потужна.";
string pattern = @"\bC#\b"; // \b - межа слова

MatchCollection matches = Regex.Matches(text, pattern);
Console.WriteLine($"Знайдено {matches.Count} збігів");
```
---

## Практичні рекомендації

### 1. Використання using

**Завжди використовуйте `using` для потоків:**

```csharp
// Правильно
using (FileStream fs = new FileStream("file.txt", FileMode.Open))
{
    // робота з файлом
}

// Неправильно (може призвести до витоку ресурсів)
FileStream fs = new FileStream("file.txt", FileMode.Open);
// забули закрити
```

### 2. Обробка помилок

```csharp
try
{
    using (StreamReader reader = new StreamReader("file.txt"))
    {
        string content = reader.ReadToEnd();
    }
}
catch (FileNotFoundException ex)
{
    Console.WriteLine($"Файл не знайдено: {ex.Message}");
}
catch (IOException ex)
{
    Console.WriteLine($"Помилка вводу/виводу: {ex.Message}");
}
```

### 3. Перевірка існування

```csharp
if (File.Exists("file.txt"))
{
    // робота з файлом
}
else
{
    Console.WriteLine("Файл не існує");
}
```

### 4. Використання Path

```csharp
string fileName = Path.Combine("folder", "subfolder", "file.txt");
string extension = Path.GetExtension(fileName);
string nameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);
```

---

## Висновок

Модуль 11 охоплює важливі аспекти роботи з файловою системою в C#:

1. **Потоки** - уніфікований спосіб роботи з даними
2. **FileStream** - робота з файлами на рівні байтів
3. **StreamReader/StreamWriter** - робота з текстом
4. **BinaryReader/BinaryWriter** - робота з двійковими даними
5. **File/Directory** - статичні методи для файлових операцій
6. **FileInfo/DirectoryInfo** - інформація про файли та директорії
7. **Regex** - регулярні вирази для пошуку та валідації

Правильне використання цих класів дозволяє ефективно працювати з файловою системою та обробляти дані в C#.

