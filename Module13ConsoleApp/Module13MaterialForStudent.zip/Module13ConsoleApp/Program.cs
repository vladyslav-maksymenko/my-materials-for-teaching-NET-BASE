﻿using Module13ConsoleApp.Serialization;
using Module13ConsoleApp.Logging;

namespace Module13ConsoleApp;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("========================================");
        Console.WriteLine("Module 13: Serialization and Logging");
        Console.WriteLine("========================================\n");

        bool continueRunning = true;

        while (continueRunning)
        {
            Console.WriteLine("\nSelect an example to run:");
            Console.WriteLine("1. Binary Serialization (Note: Requires .NET Framework)");
            Console.WriteLine("2. SOAP Serialization (Note: Requires .NET Framework)");
            Console.WriteLine("3. Custom Serialization (ISerializable)");
            Console.WriteLine("4. JSON Serialization (Modern approach)");
            Console.WriteLine("5. log4net Logging");
            Console.WriteLine("6. Serilog Logging");
            Console.WriteLine("7. NLog Logging");
            Console.WriteLine("8. Run All Serialization Examples");
            Console.WriteLine("9. Run All Logging Examples");
            Console.WriteLine("0. Exit");
            Console.Write("\nEnter your choice: ");

            string? choice = Console.ReadLine();
            Console.WriteLine();

            try
            {
                switch (choice)
                {
                    case "1":
                        BinarySerializationExample.DemonstrateBinarySerialization();
                        BinarySerializationExample.DemonstrateObjectGraphSerialization();
                        break;

                    case "2":
                        SoapSerializationExample.DemonstrateSoapSerialization();
                        break;

                    case "3":
                        CustomSerializationExample.DemonstrateCustomSerialization();
                        break;

                    case "4":
                        JsonSerializationExample.DemonstrateJsonSerialization();
                        Console.WriteLine();
                        JsonSerializationExample.DemonstrateObjectGraphJsonSerialization();
                        break;

                    case "5":
                        Log4NetExample.DemonstrateLog4Net();
                        Log4NetExample.DemonstrateLog4NetWithContext();
                        break;

                    case "6":
                        SerilogExample.DemonstrateSerilog();
                        SerilogExample.DemonstrateSerilogStructuredLogging();
                        SerilogExample.Cleanup();
                        break;

                    case "7":
                        NLogExample.DemonstrateNLog();
                        NLogExample.DemonstrateNLogWithContext();
                        break;

                    case "8":
                        Console.WriteLine("=== Running All Serialization Examples ===\n");
                        JsonSerializationExample.DemonstrateJsonSerialization();
                        Console.WriteLine();
                        JsonSerializationExample.DemonstrateObjectGraphJsonSerialization();
                        Console.WriteLine();
                        CustomSerializationExample.DemonstrateCustomSerialization();
                        Console.WriteLine();
                        BinarySerializationExample.DemonstrateBinarySerialization();
                        Console.WriteLine();
                        BinarySerializationExample.DemonstrateObjectGraphSerialization();
                        Console.WriteLine();
                        SoapSerializationExample.DemonstrateSoapSerialization();
                        break;

                    case "9":
                        Console.WriteLine("=== Running All Logging Examples ===\n");
                        Log4NetExample.DemonstrateLog4Net();
                        Log4NetExample.DemonstrateLog4NetWithContext();
                        Console.WriteLine();
                        SerilogExample.DemonstrateSerilog();
                        SerilogExample.DemonstrateSerilogStructuredLogging();
                        SerilogExample.Cleanup();
                        Console.WriteLine();
                        NLogExample.DemonstrateNLog();
                        NLogExample.DemonstrateNLogWithContext();
                        break;

                    case "0":
                        continueRunning = false;
                        Console.WriteLine("Exiting...");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n✗ Error: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
            }

            if (continueRunning && choice != "0")
            {
                Console.WriteLine("\nPress any key to continue...");
                Console.ReadKey();
                Console.Clear();
            }
        }
    }
}
